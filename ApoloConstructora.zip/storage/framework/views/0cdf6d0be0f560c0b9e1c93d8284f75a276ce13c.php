<?php $__env->startSection('contenido'); ?>

    <h3 align="center"><b>Lista de Encargados de Proyecto</b></h3>
    <div class="panel panel-primary">
        <div class="panel-body">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="table-responsive">
                        <table class="table table-striped table-bordered table-condensed table-hover">
                            <thead>
                            <th>Encargado</th>
                            <th>Proyecto</th>
                            </thead>
                            <?php $__currentLoopData = $encargados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($e->Nombre); ?> <?php echo e($e->Apellido_Paterno); ?> <?php echo e($e->Apellido_Materno); ?></td>
                                        <td><?php echo e($e->Nombre); ?></td>
                                    </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                    </div>
                    <?php echo e($encargados->render()); ?>

                </div>
            </div>
        </div>
    </div>





    <h3 align="center"><b> Prestamo de Herramientas</b></h3>
    <div class="row">
        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
            <?php if(count($errors)>0): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <?php echo Form::open(array('url'=>'RegistrarEgreso/PrestamoHerramienta','method'=>'POST','autocomplete'=>'off')); ?>

    <?php echo Form::token(); ?>


    <div class="row">
        <div class="col-lg-4 col-sm-4 col-md-4 col-xs-12">
            <div class="form-group">
                <label for="idrol">Nombre de Usuario</label>
                <select name="ID_Rol">
                    <?php $__currentLoopData = $idrol; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $idroles): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option name="ID_Rol" id="ID_Rol" value="<?php echo e($idroles->ID); ?>"><?php echo e($idroles->Nombre); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-12 col-sm-12 col-md-12 col-xs-12">
            <div class="form-group">
                <label for="proyecto">proyecto</label>
                <select name="Nro2" id="Nro2" class="form-control selectpicker" data-live-search="true" title="Escoger proyecto...">
                    <?php $__currentLoopData = $proyecto; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($p->Nro); ?>"><?php echo e($p->Nro); ?>: <?php echo e($p->Nombre); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>
        <div class="col-lg-4 col-sm-4 col-md-4 col-xs-12">
            <div class="form-group">
                <label for="herramienta">Herramienta</label>
                <select name="Codigo2" id="Codigo2" class="form-control selectpicker" data-live-search="true" title="Escoger Herramienta...">
                    <?php $__currentLoopData = $herramienta; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($h->Codigo); ?>"><?php echo e($h->Codigo); ?>: <?php echo e($h->Nombre); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>

        <div class="col-lg-4 col-sm-4 col-md-4 col-xs-12">
            <div class="form-group">
                <label for="Cantidad">Cantidad</label>
                <input type="number" name="Cantidad2" id="Cantidad2" class="form-control" placeholder="Cantidad...">
            </div>
        </div>

        <div class="col-lg-4 col-sm-4 col-md-4 col-xs-12">
            <div class="form-group">
                <label for="FechaA">Fecha Aproximada</label>
                <input type="date" name="FechaA2" id="FechaA2" class="form-control" placeholder="Introdusca la Fecha Aproximada de Devolucion...">
            </div>
        </div>

        <div class="col-lg-12 col-sm-12 col-md-12 col-xs-12">
            <div class="form-group">
                <button type="button" id="btn_add" class="btn btn-block btn-primary"> AGREGAR</button>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="panel panel-primary">
            <div class="panel-body">
                <h3 align="center"><b>Detalle de Entrega de Material</b></h3>
                <div class="col-lg-12 col-sm-12 col-md-12 col-xs-12">
                    <div class="col-lg-12 col-sm-12 col-md-12 col-xs-12">
                        <table id="detalles" class="table table-striped table-bordered table-condensed table-hover">
                            <thead>
                            <th>Opciones</th>
                            <th>Nombre del Proyecto</th>
                            <th>Material</th>
                            <th>Cantidad</th>
                            <th>Fecha Aproximada de Devolucion</th>
                            </thead>
                            <tfoot>
                            <th></th>
                            <th></th>
                            <th></th>
                            <th></th>
                            <th></th>
                            </tfoot>
                            <tbody>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-6 col-sm-6 col-md-6 col-xs-12" id="guardar">
            <div class="form-group">
                <input name="_token" value="<?php echo e(csrf_token()); ?>" type="hidden">
                <button class="btn btn-primary" type="submit">Guardar</button>
                <button class="btn btn-danger" type="reset">Cancelar</button>
            </div>
        </div>
    </div>

    <?php echo Form::close(); ?>


    <?php $__env->startPush('scripts'); ?>
    <script>
        $(document).ready(function () {
            $('#btn_add').click(function () {
                agregar();
            });
        });

        var hoy = new Date();

        c = 0;

        $("#guardar").hide();

        function agregar() {


            Nro = $("#Nro2").val();
            proyecto = $("#Nro2 option:selected").text();

            Codigo = $("#Codigo2").val();
            herramienta = $("#Codigo2 option:selected").text();

            cantidad = $("#Cantidad2").val();

            fecha = $("#FechaA2").val();

            if(proyecto != "" && proyecto!= "Escoger proyecto..." && herramienta != "" && herramienta != "Escoger Herramienta..."  && cantidad != "" && cantidad > 0 && fecha != "" && fecha != "Introdusca la Fecha Aproximada de Devolucion..."){

                var fila = '<tr class="selected" id="fila'+c+'"><td><button type="button" class="btn btn-warning" onclick="eliminar('+c+');">X</button></td><td><input id="Nro" type="hidden" name="Nro" value="'+Nro+'">'+proyecto+'</td><td><input id="Codigo" type="hidden" name="Codigo[]" value="'+Codigo+'">'+herramienta+'</td><td><input id="Cantidad" type="number" name="Cantidad[]" value="'+cantidad+'" ></td><td><input id="FechaA" type="date" name="FechaA" value="'+fecha+'" ></td></tr>';

                c++;
                limpiar();
                evaluar();
                $('#detalles').append(fila);
            }else{
                alert("Error al ingresar el detalle de prestamo, revise los datos");
            }
        }

        function limpiar(){
            $("#Cantidad2   ").val("");
            $("#Codigo2").val("");
        }

        function evaluar(){
            if (c > 0){
                $("#guardar").show();
            }
            else{
                $("#guardar").hide();
            }
        }

        function eliminar(index) {
            $("#fila" + index).remove();
            c--;
            evaluar();
        }

    </script>
    <?php $__env->stopPush(); ?>
    </div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>