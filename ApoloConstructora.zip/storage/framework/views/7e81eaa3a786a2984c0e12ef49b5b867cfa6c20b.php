<?php $__env->startSection('contenido'); ?>
    <div class="row">
        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
            <h3>Editar Usuario : <?php echo e($usuario->Id); ?></h3>
            <?php if(count($errors)>0): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <?php echo Form::model($usuario,['method'=>'PATCH','route'=>['AdministrarUsuario.update',$usuario->Per_CI]]); ?>

            <?php echo e(Form::token()); ?>


            <div class="form-group">
                <label for="Id">ID</label>
                <input type="text" name="Id" class="form-control" value="<?php echo e($usuario->ID); ?>">
            </div>

            <div class="form-group">
                <label for="Contraseña">Contraseña</label>
                <input type="text" name="Contraseña" class="form-control" value="<?php echo e($usuario->Contraseña); ?>">
            </div>

            <div class="form-group">
                <label>Grupo</label>
                <select name="Codigo_G" class="form-control">
                    <?php $__currentLoopData = $grupo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tpp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($tpp->Id==$usuario->Codigo_G): ?>
                            <option value="<?php echo e($tpp->Id); ?>" selected><?php echo e($tpp->Descripcion); ?></option>
                        <?php else: ?>
                            <option value="<?php echo e($tpp->Id); ?>"><?php echo e($tpp->Descripcion); ?></option>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="form-group">
                <button class="btn btn-primary" type="submit">Guardar</button>
                <button class="btn btn-danger" type="reset">Cancelar</button>
            </div>



            <?php echo Form::close(); ?>


        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>