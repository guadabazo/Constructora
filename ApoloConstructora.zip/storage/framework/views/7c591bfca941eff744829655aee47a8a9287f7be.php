<?php $__env->startSection('contenido'); ?>

    <div class = "row">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <h3>Lista de CHOFERES<a href="GestionarChofer/create"><button class="btn btn-success pull-right">Nuevo CHofer</button></a></h3>
            <?php echo $__env->make('Gestionar.GestionarChofer.search', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
    </div>
    <h3></h3>
    <div class="panel panel-primary">
        <div class="panel-body">
            <div class = "row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="table-responsive">
                        <table class="table table-striped table-bordered table-condensed table-hover">
                            <thead>
                            <th>LICENCIA</th>
                            <th>CI</th>
                            <th>Nombre Y Apellido</th>
                            <th>Opciones</th>
                            </thead>
                            <?php $__currentLoopData = $choferes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($p->Licencia); ?></td>
                                    <td><?php echo e($p->CI); ?></td>
                                    <td><?php echo e($p->Nombre); ?> <?php echo e($p->Apellido_Paterno); ?> <?php echo e($p->Apellido_Materno); ?></td>
                                    <td>
                                        <a href="<?php echo e(URL::action('ChoferController@edit',$p->CI)); ?>"><button class="btn btn-danger">Editar</button></a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                    </div>
                    <?php echo e($choferes->render()); ?>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>