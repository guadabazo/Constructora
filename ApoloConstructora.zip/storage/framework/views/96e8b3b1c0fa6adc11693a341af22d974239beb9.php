<?php $__env->startSection('contenido'); ?>
    <div class = "row">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <h3>Roles De la Empresa<a href="persona/create"><button class="btn btn-success pull-right">Nuevo Rol</button></a></h3>

        </div>
    </div>

    <div class = "row">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <div class="table-responsive">
                <table class="table table-striped table-bordered table-condensed table-hover">
                    <thead>
                    <th>Id</th>
                    <th>Descripcion</th>
                    <th>CI</th>
                    <th>Nombre y Apellido</th>
                    <th>Opciones</th>
                    </thead>
                    <?php $__currentLoopData = $Roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th><?php echo e($r->ID); ?></th>
                            <td><?php echo e($r->Descripcion); ?></td>
                            <td><?php echo e($r->Per_CI); ?></td>
                            <td><?php echo e($r->N); ?></td>
                            <td>
                                <a href="<?php echo e(URL::action('RolController@edit',$r->ID)); ?>"><button class="btn btn-info">Editar</button></a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
            </div>
            <?php echo e($Roles->render()); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>