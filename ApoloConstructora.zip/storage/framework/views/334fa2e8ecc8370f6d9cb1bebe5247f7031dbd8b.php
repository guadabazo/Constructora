<?php $__env->startSection('contenido'); ?>
    <section class="content-header">
        <h1>INVENTARIO</h1>
        <section class="content">
            <div class="col-md-6 col-sm- col-xs-12">
                <div class="col-xs-6 table">
                    <button type="button" class="btn btn-block bg-maroon btn-flat margin">DOTACION</button>
                    <?php echo $__env->make('Administrar.AdministrarInventario.search', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Nombre</th>
                                <th>Cantidad</th>
                            </tr>
                        <tbody>
                        </tbody>
                    </table>
                </div>
            </div>

            <div class="col-md-6 col-sm-6 col-xs-12">
                <div class="col-xs-6 table">
                    <button type="button" class="btn btn-block bg-blue btn-flat margin">HERRAMIENTAS</button>
                    <?php echo $__env->make('Administrar.AdministrarInventario.search', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Nombre</th>
                                <th>Cantidad</th>
                            </tr>
                        </thead>
                        <tbody>
                        </tbody>
                    </table>
                </div>
            </div>
            <!-- /.col -->
            <div class="col-md-6 col-sm-6 col-xs-12">
                <div class="col-xs-6 table">
                    <button type="button" class="btn btn-block bg-green btn-flat margin">MATERIAL</button>
                    <?php echo $__env->make('Administrar.AdministrarInventario.search', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <table class="table table-striped">
                        <thead>
                            <th>Nombre</th>
                            <th>Cantidad</th>
                        </thead>
                        <?php $__currentLoopData = $material; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($m->Nombre); ?></td>
                                <td><?php echo e($m->Cantidad); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>
            </div>

            <div class="col-md-6 col-sm-6 col-xs-12">
                <div class="">
                    <div class="">
                        <div class="col-xs-6 table">
                            <button type="button" class="btn btn-block bg-red btn-flat margin">PROYECTO</button>
                            <?php echo $__env->make('Administrar.AdministrarInventario.search', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                            <table class="table table-striped">
                                <thead>
                                <tr>
                                    <th>Nombre</th>
                                    <th>Cantidad</th>
                                </tr>
                                </thead>
                                <tbody>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <!-- /.info-box-content -->
                </div>
                <!-- /.info-box -->
            </div>
            <!-- /.col -->
            <!-- /.col -->
        </section>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>