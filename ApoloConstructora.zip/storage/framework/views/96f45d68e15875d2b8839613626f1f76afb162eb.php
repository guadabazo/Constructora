<?php $__env->startSection('contenido'); ?>
    <div class = "row">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <h3>Listado de Material <a href="<?php echo e(url('Registrar/Registrar_Ingreso_Material')); ?>"><button class="btn btn-success pull-right">Nuevo Material</button></a></h3>
        </div>
    </div>

    <div class = "row">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <div class="table-responsive">
                <table class="table table-striped table-bordered table-condensed table-hover">
                    <thead>
                    <th>Codigo</th>
                    <th>Nombre</th>
                    <th>Cantidad</th>
                    <th>Unidad de Medida</th>
                    <th>Deposito Numero</th>
                    <th>Tipo</th>
                    </thead>

                </table>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>