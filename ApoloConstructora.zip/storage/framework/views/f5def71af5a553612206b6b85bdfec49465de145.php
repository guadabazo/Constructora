<?php $__env->startSection('contenido'); ?>

    <div class="row">
        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
            <h3>EDITAR CATEGORIA:<?php echo e($Roles->Per_CI); ?></h3>

            <?php echo Form::model($Roles,['method'=>'PATCH','route'=>['GestionarRol.update',$Roles->ID]]); ?>

            <?php echo e(Form::token()); ?>


            <div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
                <div class="form-group">
                    <label>Tipo</label>
                    <select name="Descripcion" class="form-control">
                        <option value ="<?php echo e($Roles->Descripcion); ?>" selected><?php echo e($Roles->Descripcion); ?></option>
                        <option value="ADMINISTRADOR">Administrador</option>
                        <option value="BODEGUERO">Bodeguero</option>
                    </select>
                </div>
            </div>


            <div class="row">
                <div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
                    <div class="form-group">
                        <label>Carnet</label>
                        <select name="Per_CI" class="form-control">
                            <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($u->Per_CI==$Roles->Per_CI): ?>
                                    <option value="<?php echo e($u->Per_CI); ?>" selected><?php echo e($u->Per_CI); ?> </option>
                                <?php else: ?>
                                    <option value="<?php echo e($u->Per_CI); ?>"><?php echo e($u->Per_CI); ?> </option>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>

            </div>

            <div class="row">
                <div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
                    <div class="form-group">
                        <button class="btn btn-primary" type="submit">Guardar</button>
                        <button href="Gestionar/GestionarRol" class="btn btn-danger">Cancelar</button>
                    </div>
                </div>
            </div>
            <?php echo Form::close(); ?>


        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>