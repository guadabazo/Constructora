<?php $__env->startSection('contenido'); ?>
    <div class = "row">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <h3>Listado de Materiales Escasos</h3>
            <?php echo $__env->make('administrar.administrar material.search', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
    </div>

    <div class="panel panel-primary">
        <div class="panel-body">
    <div class = "row">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <div class="table-responsive">
                <table class="table table-striped table-bordered table-condensed table-hover">
                    <thead>
                    <th>Codigo</th>
                    <th>Nombre</th>
                    <th>Cantidad</th>
                    <th>Unidad de Medida</th>
                    <th>Nomenclatura</th>
                    <th>Deposito Numero</th>
                    <th>Tipo</th>
                    </thead>
                    <?php $__currentLoopData = $materiales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($mat->Cantidad < 100000): ?>
                        <tr>
                            <td><?php echo e($mat->Codigo); ?></td>
                            <td><?php echo e($mat->N); ?></td>
                            <td><?php echo e($mat->Cantidad); ?></td>
                            <td><?php echo e($mat->Descripcion); ?></td>
                            <td><?php echo e($mat->Abreviatura); ?></td>
                            <td><?php echo e($mat->Nombre); ?></td>
                            <td><?php echo e($mat->Tipo); ?></td>
                        </tr>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
            </div>
            <?php echo e($materiales->render()); ?>

        </div>
    </div>
    </div>
    </div>

    <div class = "row">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <h3>Listado de Materiales  </h3>
            <?php echo $__env->make('administrar.administrar material.search', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
    </div>

    <div class="panel panel-primary">
        <div class="panel-body">
    <div class = "row">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <div class="table-responsive">
                <table class="table table-striped table-bordered table-condensed table-hover">
                    <thead>
                    <th>Codigo</th>
                    <th>Nombre</th>
                    <th>Cantidad</th>
                    <th>Unidad de Medida</th>
                    <th>Nomenclatura</th>
                    <th>Deposito Numero</th>
                    <th>Tipo</th>
                    </thead>
                    <?php $__currentLoopData = $materiales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($mat->Cantidad >= 100000): ?>
                        <tr>
                            <td><?php echo e($mat->Codigo); ?></td>
                            <td><?php echo e($mat->N); ?></td>
                            <td><?php echo e($mat->Cantidad); ?></td>
                            <td><?php echo e($mat->Descripcion); ?></td>
                            <td><?php echo e($mat->Abreviatura); ?></td>
                            <td><?php echo e($mat->Nombre); ?></td>
                            <td><?php echo e($mat->Tipo); ?></td>
                        </tr>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
            </div>
            <?php echo e($materiales->render()); ?>

        </div>
    </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>