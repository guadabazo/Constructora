<?php $__env->startSection('contenido'); ?>

    <div class = "row">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <h3>Lista de trabajadores<a href="GestionarTrabajador/create"><button class="btn btn-success pull-right">Nuevo Trabajador</button></a></h3>
            <?php echo $__env->make('Gestionar.GestionarTrabajador.search', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
    </div>
    <h3></h3>
    <div class="panel panel-primary">
        <div class="panel-body">
            <div class = "row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="table-responsive">
                        <table class="table table-striped table-bordered table-condensed table-hover">
                            <thead>
                            <th>ID Trabajador</th>
                            <th>CI</th>
                            <th>Nombre y Apellido</th>
                            <th>Tipo de Trabajador</th>
                            <th>Opciones</th>
                            </thead>
                            <?php $__currentLoopData = $trabajador; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($p->ID_Trabajador); ?></td>
                                    <td><?php echo e($p->CI); ?></td>
                                    <td><?php echo e($p->Nombre); ?> <?php echo e($p->Apellido_Paterno); ?> <?php echo e($p->Apellido_Materno); ?></td>
                                    <?php if($p->TipoCh == 'V'): ?>
                                        <td>Chofer</td>
                                    <?php endif; ?>
                                    <?php if($p->TipoO == 'V'): ?>
                                        <td>Otro Trabajador</td>
                                    <?php endif; ?>
                                    <td>
                                        <a href="<?php echo e(URL::action('TrabajadorController@edit',$p->CI)); ?>"><button class="btn btn-danger">Editar</button></a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                    </div>
                    <?php echo e($trabajador->render()); ?>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>