<?php

namespace ApoloConstructora\Http\Controllers;

use Illuminate\Http\Request;

use ApoloConstructora\inventario;
use Illuminate\Support\Facades\Redirect;
use ApoloConstructora\Http\Requests\InventarioFormRequest;
use DB;

class InventarioController extends Controller
{
    public function __construct()
    {

    }

    public function index(Request $request)
    {

        if ($request)
        {
            $query=trim($request->get('searchText'));
            $inventarioMate=DB::table('inventario_material as im')
                ->join('material as m','im.Codigo_Material','=','m.Codigo')
                ->select('m.Nombre','m.Cantidad')
                ->where ('m.codigo','LIKE','%'.$query.'%')
                ->orderBy('m.codigo','desc')
                ->groupBy('m.Nombre','m.Cantidad')
                ->paginate(5);
            return view ('Administrar.AdministrarInventario.index',["material"=>$inventarioMate,"searchText"=>$query]);

        }
    }

    public function create()
    {

    }
    public function show($id)
    {
        /*	$inventarioMate=DB::table('Inventario as i')
            ->join('material as m','i.Codigo_Material','=','m.Codigo')
            ->select('m.nombre','m.cantidad')
            ->where ('i.codigo','LIKE','%'.$query.'%');*/
    }
}
