<?php

namespace ApoloConstructora\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use ApoloConstructora\Http\Requests\LoginFormRequest;
use DB;

class LoginController extends Controller
{
    public function index(){
        return view('login.user.index');
    }

    public function store(LoginFormRequest $request){

        $conexion=  mysqli_connect("www.apoloc.esy.es", "u370504422", "123456789", "bdapoloconstructora1");
        $correo = trim($_POST['usuario']);
        $clave = trim($_POST['Contraseña']);

        $consulta = "SELECT * FROM usuario
	                 WHERE Id = '$correo' and 
	                 Contrasena = '$clave'";

        $usuario =DB::table('usuario')
            ->where('usuario.Id','=',$correo)
            ->where('usuario.Contrasena','=',$clave)
            ->select('usuario.Id','usuario.Codigo_G')
            ->get();
        error_reporting(E_ALL and E_NOTICE);
        session_start();
        $_SESSION['username'] = $correo;

        $r = mysqli_query( $conexion,$consulta); //consulta si los valores son correctos
        $result = mysqli_num_rows($r); // si devuelve alguna fila significa que es correcto

        if ($result > 0){
            session_start();
            $fila=  mysqli_fetch_row($r);
            if($fila[3]=='40000'){
                return Redirect::to('admin');
                //return view('layouts.admin',["usuario" => $usuario]);
            }

            if($fila[3]=='40001'){
                //return view('layouts.admin',["usuario" => $usuario]);
                return Redirect::to('admin');
            }
        }



    }
}

