<?php

namespace ApoloConstructora\Http\Controllers;

use Illuminate\Http\Request;

use ApoloConstructora\Requests;
use ApoloConstructora\Rol;
use Illuminate\Support\Facades\Redirect;
use ApoloConstructora\Http\Requests\RolFormRequest;
use DB;

class RolController extends Controller
{
    public function __construct()
    {
    }

    public function index(Request $request)
    {
        if($request){
            $query=trim($request->get('searchText'));
            $Roles=DB::table('Rol as r')
                ->join('usuario as u','r.Per_CI','=','u.Per_CI')
                ->join('persona as p','p.CI','=','u.Per_CI')
                ->select('r.ID','r.Descripcion','r.Per_CI',DB::raw('CONCAT(p.Nombre, " ",p.Apellido_Paterno," ",p.Apellido_Materno) as N'))
                ->where('r.ID','LIKE','%'.$query.'%')
                ->paginate(7);
            return view('Gestionar.GestionarRol.index',["Roles"=>$Roles,"searchText"=>$query]);
        }
    }

    public function create()
    {
        $usuarios=DB::table('usuario')->get();
        return view("Gestionar.GestionarRol.create",["usuarios"=>$usuarios]);
    }

    public function store(RolFormRequest $request)
    {
        $Roles=new Rol;
        $Roles->Descripcion=$request->get('Descripcion');
        $Roles->Per_CI=$request->get('Per_CI');
        $Roles->save();
        return Redirect::to('Gestionar/GestionarRol');
    }

    public function show($id)
    {
        return view("Gestionar.GestionarRol.show",["Roles"=>Rol::findOrFail($id)]);
    }

    public function edit($id)
    {
        $Roles=Rol::findOrFail($id);
        $usuarios=DB::table('usuario')->get();
        return view("Gestionar.GestionarRol.edit",["Roles"=>$Roles,"usuarios"=>$usuarios]);
    }

    public function update(RolFormRequest $request,$id)
    {
        $Roles=Rol::findOrFail($id);
        $Roles->Descripcion=$request->get('Descripcion');
        $Roles->Per_CI=$request->get('Per_CI');
        $Roles->update();
        return Redirect::to('Gestionar/GestionarRol');
    }

    public function destroy($id)
    {
    }

}
