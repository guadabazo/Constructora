<?php

namespace ApoloConstructora;

use Illuminate\Database\Eloquent\Model;

class DetalleProduccion extends Model
{
    //
}
